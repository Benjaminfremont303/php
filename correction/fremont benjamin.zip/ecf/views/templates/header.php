<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/header.css">
    <link rel="stylesheet" href="style/voirPostParTheme.css">
    <link rel="stylesheet" href="style/groups.css">
    <title>Document</title>
</head>

<body>
    <h1>PassionGuimauve.com Le meilleur et le seul site de creation de blog sur le theme de la guimauve</h1>
    <ul class="menu-bar">
        <li><a href="/">Acueill</a></li>
        <li><a href="VoirPostParTheme">Les derniers Posts</a></li>
        <li><a href="groups">Voir les groupes</a> </li>
        <li><a href="">se connecter</a></li>
        <li><a href="">s'incrire</a></li>
    </ul>
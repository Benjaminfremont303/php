<form action="" class="update" method="post">
    <label for="title">titre</label>
    <input id="title" name="title" type="text">

    <label for="content">contenu</label>
    <input id="content" name="content" type="text">
    <input type="submit" value="changer">
</form>